﻿using System;

namespace OrderStrings
{
    public class OrderStringsClass
    {
        static void OrderStringsByLength(string[] s, int n)
        {
            for (int i = 1; i < n; i++)
            {
                string temp = s[i];
                int j = i - 1;
                while (j >= 0 && temp.Length < s[j].Length)
                {
                    s[j + 1] = s[j];
                    j--;
                }
                s[j + 1] = temp;

            }
        }
        static void Arraystring(string[] str, int n)
        {
            for (int i = 0; i < n; i++)
                Console.Write(str[i] + " ");
        }

        static public void OrderStringsByLength()
        {
            Console.WriteLine("Enter the sentence in English");
            string text = Console.ReadLine();
            string[] s = text.Split(' ');
            int n = s.Length;
            OrderStringsByLength(s, n);
            Arraystring(s, n);

        }

    }
}
