﻿using System;

namespace CountOfVowelsLIB
{
    public class CountClass
    {
        static public int CountOfVowels()
        {
            int count_of_Vowels = 0;
            Console.WriteLine("Enter the sentence in English");
            char[] s = Console.ReadLine().ToCharArray();
            char[] Vowels = { 'a', 'e', 'i', 'o', 'u' };
            for (int i = 0; i < s.Length; i++)
                for (int j = 0; j < Vowels.Length; j++)
                    if (s[i] == Vowels[j])
                    {
                        count_of_Vowels++;
                    }
            Console.WriteLine("the number of vowels in the sentence " + count_of_Vowels);
            return count_of_Vowels;
        }
     }

    }

