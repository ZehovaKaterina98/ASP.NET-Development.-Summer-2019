﻿using System;
using GetGCD;
using RemoveWords;
using CountOfVowelsLIB;
using OrderStrings;

namespace Home_page
{
    class Selection_of_Actions
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Choose one of the actions");
            Console.WriteLine("\n 1.Finding  GCD \n 2.Vowel count in a sentence \n 3.Аrray sorting \n 4.Remove duplicate words from string");
            int v = int.Parse(Console.ReadLine());
            switch (v)
            { case 1:
                    GCDClass.gcd();
                    break;
             case 2:
                    CountClass.CountOfVowels();
                break;
             case 3:
                    OrderStringsClass.OrderStringsByLength();
                    break;
             case 4:
                    RemoveWordsClass.RemoveDublicateWords();
             break;

            }
            Console.ReadKey();
        }
    }
}
