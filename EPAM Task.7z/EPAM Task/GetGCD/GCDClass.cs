﻿using System;

namespace GetGCD
{
    public class GCDClass
    {
        static public int gcd(int a, int b)
        {
            if (b == 0)
                return a;
            return gcd(b, a % b);
        }
        static public void gcd()
        {
            Console.WriteLine("Enter а");
            int a = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter b");
            int b = int.Parse(Console.ReadLine());
            Console.WriteLine("GCD numbers "+ a + " and numbers " + b + " this "+ gcd(a, b));
        }


    }
}
