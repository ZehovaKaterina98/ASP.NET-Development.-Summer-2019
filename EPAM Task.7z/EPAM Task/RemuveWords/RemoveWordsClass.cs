﻿using System;
using System.Text.RegularExpressions;

namespace RemoveWords
{
    public class RemoveWordsClass
    {
        static public void RemoveDublicateWords()
        {
            Console.WriteLine("Enter offer");
            string sentence = Console.ReadLine();
            var result = Regex.Replace(sentence, @"(\w+).*?\1", "$1");
            Console.WriteLine("your result - " + result);
        }
     
    }
}
